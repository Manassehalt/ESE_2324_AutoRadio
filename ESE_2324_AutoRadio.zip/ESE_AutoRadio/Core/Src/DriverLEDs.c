/*
 * DriverLEDs.c
 *
 *  Created on: Dec 4, 2024
 *      Author: nolan
 */

#include "DriverLEDs.h"
#include "shell.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define CS_GPIO_PORT GPIOB   // Port pour la broche CS
#define CS_PIN GPIO_PIN_7    // Pin pour la broche CS

void LED_Driver_Init(LED_Driver_t *driver, SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin) {
    driver->hspi = hspi;
    driver->cs_port = cs_port;
    driver->cs_pin = cs_pin;
    driver->gpioa_state = 0x00;
    driver->gpiob_state = 0x00;

    uint8_t data[3];

    HAL_GPIO_WritePin(CS_GPIO_PORT, CS_PIN, GPIO_PIN_SET);   // CS HIGH
    HAL_Delay(1);

    // Configurer GPIOA (IODIRA) en sortie
    data[0] = 0x40;
    data[1] = 0x00;
    data[2] = 0x00;
    HAL_GPIO_WritePin(driver->cs_port, driver->cs_pin, GPIO_PIN_RESET); // CS LOW
    HAL_SPI_Transmit(driver->hspi, data, 3, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(driver->cs_port, driver->cs_pin, GPIO_PIN_SET);   // CS HIGH
    HAL_Delay(1);

    // Configurer GPIOB (IODIRB) en sortie
    data[0] = 0x40;
    data[1] = 0x01;
    data[2] = 0x00;
    HAL_GPIO_WritePin(driver->cs_port, driver->cs_pin, GPIO_PIN_RESET); // CS LOW
    HAL_SPI_Transmit(driver->hspi, data, 3, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(driver->cs_port, driver->cs_pin, GPIO_PIN_SET);   // CS HIGH
    HAL_Delay(1);
}

void LED_Driver_SetGPIOA(LED_Driver_t *driver, uint8_t state) {
	uint8_t data[3];
    driver->gpioa_state = state;

    data[0] = 0x40;
    data[1] = 0x14;
    data[2] = state;
    HAL_GPIO_WritePin(driver->cs_port, driver->cs_pin, GPIO_PIN_RESET); // CS LOW
    HAL_SPI_Transmit(driver->hspi, data, 3, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(driver->cs_port, driver->cs_pin, GPIO_PIN_SET);   // CS HIGH
    HAL_Delay(1);
}

void LED_Driver_SetGPIOB(LED_Driver_t *driver, uint8_t state) {
	uint8_t data[3];
    driver->gpiob_state = state;

    data[0] = 0x40;
    data[1] = 0x15;
    data[2] = state;
    HAL_GPIO_WritePin(driver->cs_port, driver->cs_pin, GPIO_PIN_RESET); // CS LOW
    HAL_SPI_Transmit(driver->hspi, data, 3, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(driver->cs_port, driver->cs_pin, GPIO_PIN_SET);   // CS HIGH
    HAL_Delay(1);
}

int shell_setled(h_shell_t *h_shell, int argc, char **argv) {
    if (argc != 4) {
        snprintf(h_shell->print_buffer, BUFFER_SIZE, "Usage: s <port> <led> <state>\n");
        h_shell->drv.transmit(h_shell->print_buffer, strlen(h_shell->print_buffer));
        return -1;
    }

    uint8_t port = atoi(argv[1]);  // Port : 0 (GPIOA) ou 1 (GPIOB)
    uint8_t led = atoi(argv[2]);   // Indice de la LED : 0 à 7
    uint8_t state = atoi(argv[3]); // État : 0 (OFF) ou 1 (ON)

    // Validation des arguments
    if ((port > 1) || (led > 7) || (state > 1)) {
        snprintf(h_shell->print_buffer, BUFFER_SIZE, "Error: Invalid arguments.\n");
        h_shell->drv.transmit(h_shell->print_buffer, strlen(h_shell->print_buffer));
        return -1;
    }

    // Contrôler la LED via le driver
    LED_Driver_SetLED(&led_driver, port, led, state);

    // Répondre via le shell
    snprintf(h_shell->print_buffer, BUFFER_SIZE, "LED %d on GPIO%s set to %s\n",
             led, (port == 0) ? "A" : "B", (state == 1) ? "ON" : "OFF");
    h_shell->drv.transmit(h_shell->print_buffer, strlen(h_shell->print_buffer));

    return 0;
}

