/*
 * shell.c
 *
 *  Created on: 7 juin 2019
 *      Author: Laurent Fiack
 */

#include "shell.h"
#include <stdio.h>
#include <string.h>

// Commande par défaut : affichage de l'aide
int sh_help(h_shell_t *h_shell, int argc, char **argv) {
    for (int i = 0; i < h_shell->func_list_size; i++) {
        int size = snprintf(h_shell->print_buffer, BUFFER_SIZE, "%c: %s\r\n",
                            h_shell->func_list[i].c, h_shell->func_list[i].description);
        h_shell->drv.transmit(h_shell->print_buffer, size);
    }
    return 0;
}

// Initialisation du shell
void shell_init(h_shell_t *h_shell) {
    int size;

    h_shell->func_list_size = 0;

    size = snprintf(h_shell->print_buffer, BUFFER_SIZE, "\r\n===== Shell v0.2 =====\r\n");
    h_shell->drv.transmit(h_shell->print_buffer, size);

    size = snprintf(h_shell->print_buffer, BUFFER_SIZE, "Welcome to the shell!\r\n");
    h_shell->drv.transmit(h_shell->print_buffer, size);

    // Ajouter la commande d'aide
    shell_add(h_shell, 'h', sh_help, "Display help");
}

// Ajouter une commande au shell
int shell_add(h_shell_t *h_shell, char c, shell_func_pointer_t pfunc, char *description) {
    if (h_shell->func_list_size < SHELL_FUNC_LIST_MAX_SIZE) {
        h_shell->func_list[h_shell->func_list_size].c = c;
        h_shell->func_list[h_shell->func_list_size].func = pfunc;
        h_shell->func_list[h_shell->func_list_size].description = description;
        h_shell->func_list_size++;
        return 0;
    }
    return -1; // Erreur si la liste est pleine
}

// Exécuter une commande shell
static int shell_exec(h_shell_t *h_shell, char *buf) {
    char c = buf[0]; // Le premier caractère est la commande
    int argc = 1;
    char *argv[ARGC_MAX];
    argv[0] = buf;

    // Séparer les arguments
    for (char *p = buf; *p != '\0' && argc < ARGC_MAX; p++) {
        if (*p == ' ') {
            *p = '\0';
            argv[argc++] = p + 1;
        }
    }

    // Trouver et exécuter la commande
    for (int i = 0; i < h_shell->func_list_size; i++) {
        if (h_shell->func_list[i].c == c) {
            return h_shell->func_list[i].func(h_shell, argc, argv);
        }
    }

    // Commande non trouvée
    int size = snprintf(h_shell->print_buffer, BUFFER_SIZE, "%c: command not found\r\n", c);
    h_shell->drv.transmit(h_shell->print_buffer, size);
    return -1;
}

// Traitement des caractères reçus
void shell_process_char(h_shell_t *h_shell, char c) {
    static int pos = 0;

    if (c == '\r') { // Commande terminée
        h_shell->cmd_buffer[pos++] = '\0';
        shell_exec(h_shell, h_shell->cmd_buffer);
        pos = 0; // Réinitialiser le buffer
    } else if (c == '\b' && pos > 0) { // Backspace
        pos--;
    } else if (pos < BUFFER_SIZE - 1) { // Ajouter le caractère au buffer
        h_shell->cmd_buffer[pos++] = c;
    }
}

// Fonction principale du shell
int shell_run(h_shell_t *h_shell) {
    while (1) {
        char c;
        h_shell->drv.receive(&c, 1); // Lire un caractère via le driver
        shell_process_char(h_shell, c); // Traiter le caractère
    }
    return 0;
}

