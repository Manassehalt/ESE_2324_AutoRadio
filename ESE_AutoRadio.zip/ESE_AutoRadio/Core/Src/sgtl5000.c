#include "sgtl5000.h"

HAL_StatusTypeDef sgtl5000_i2c_write_register(h_sgtl5000_t *h_sgtl5000, uint16_t reg, uint16_t value)
{
    printf("Début de la fonction sgtl5000_i2c_write_register\r\n");

    uint8_t data[4];
    data[0] = (reg >> 8) & 0xFF;
    data[1] = reg & 0xFF;
    data[2] = (value >> 8) & 0xFF;
    data[3] = value & 0xFF;

    HAL_StatusTypeDef ret = HAL_I2C_Master_Transmit(h_sgtl5000->i2c_handle, 0x14 << 1, data, 4, HAL_MAX_DELAY);

    if (ret != HAL_OK) {
        printf("Erreur HAL_I2C_Master_Transmit : %d\r\n", ret);
    }
    return ret;
}


HAL_StatusTypeDef sgtl5000_i2c_read_register(h_sgtl5000_t *h_sgtl5000, uint16_t reg, uint16_t *value)
{
    uint8_t reg_addr[2];
    uint8_t data[2];
    reg_addr[0] = (reg >> 8) & 0xFF;
    reg_addr[1] = reg & 0xFF;
    HAL_StatusTypeDef ret = HAL_I2C_Master_Transmit(h_sgtl5000->i2c_handle, 0x14 << 1, reg_addr, 2, HAL_MAX_DELAY);
    if (ret != HAL_OK) return ret;
    ret = HAL_I2C_Master_Receive(h_sgtl5000->i2c_handle, 0x14 << 1, data, 2, HAL_MAX_DELAY);
    if (ret != HAL_OK) return ret;
    *value = (data[0] << 8) | data[1];
    return HAL_OK;
}

// Fonction pour définir des bits spécifiques dans un registre
HAL_StatusTypeDef sgtl5000_i2c_set_bit(h_sgtl5000_t *h_sgtl5000, uint16_t reg, uint16_t mask)
{
    uint16_t value;
    HAL_StatusTypeDef ret = sgtl5000_i2c_read_register(h_sgtl5000, reg, &value);
    if (ret != HAL_OK) return ret;
    value |= mask;
    return sgtl5000_i2c_write_register(h_sgtl5000, reg, value);
}

// Fonction pour effacer des bits spécifiques dans un registre
HAL_StatusTypeDef sgtl5000_i2c_clear_bit(h_sgtl5000_t *h_sgtl5000, uint16_t reg, uint16_t mask)
{
    uint16_t value;
    HAL_StatusTypeDef ret = sgtl5000_i2c_read_register(h_sgtl5000, reg, &value);
    if (ret != HAL_OK) return ret;
    value &= ~mask;
    return sgtl5000_i2c_write_register(h_sgtl5000, reg, value);
}

// Fonction principale d'initialisation
HAL_StatusTypeDef sgtl5000_init(h_sgtl5000_t *h_sgtl5000)
{
    HAL_StatusTypeDef ret = HAL_OK;

    // Désactivation des alimentations de démarrage
    uint16_t mask = (1 << 12) | (1 << 13);
    ret = sgtl5000_i2c_clear_bit(h_sgtl5000, SGTL5000_CHIP_ANA_POWER, mask);
    if (ret != HAL_OK) return ret;

    // Configuration de la pompe de charge
    mask = (1 << 5) | (1 << 6);
    ret = sgtl5000_i2c_set_bit(h_sgtl5000, SGTL5000_CHIP_LINREG_CTRL, mask);
    if (ret != HAL_OK) return ret;

    // Configuration de la tension de référence et du courant de polarisation
    mask = 0x01FF; // VAG_VAL = 1.575V, BIAS_CTRL = -50%, SMALL_POP = 1
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_REF_CTRL, mask);
    if (ret != HAL_OK) return ret;

    // Configuration des sorties audio
    mask = 0x031E; // LO_VAGCNTRL = 1.65V, OUT_CURRENT = 0.36mA
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_LINE_OUT_CTRL, mask);
    if (ret != HAL_OK) return ret;

    // Activation de la détection de court-circuit
    mask = 0x1106; // MODE_CM = 2, MODE_LR = 1, LVLADJC = 200mA, LVLADJL = 75mA, LVLADJR = 50mA
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_SHORT_CTRL, mask);
    if (ret != HAL_OK) return ret;

    // Configuration des blocs analogiques
    mask = 0x0004; // Unmute all + SELECT_ADC = LINEIN
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_ANA_CTRL, mask);
    if (ret != HAL_OK) return ret;

    // Activation des blocs analogiques et numériques nécessaires
    mask = 0x6AFF; // LINEOUT_POWERUP, ADC_POWERUP, CAPLESS_HEADPHONE_POWERUP, DAC_POWERUP, etc.
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_ANA_POWER, mask);
    if (ret != HAL_OK) return ret;

    mask = 0x0073; // I2S_IN_POWERUP, I2S_OUT_POWERUP, DAP_POWERUP, DAC_POWERUP, ADC_POWERUP
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_DIG_POWER, mask);
    if (ret != HAL_OK) return ret;

    // Réglage du volume des sorties audio
    mask = 0x1111; // Volume pour LINEOUT
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_LINE_OUT_VOL, mask);
    if (ret != HAL_OK) return ret;

    // Configuration des horloges
    mask = 0x0004; // SYS_FS = 48kHz
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_CLK_CTRL, mask);
    if (ret != HAL_OK) return ret;

    mask = 0x0130; // DLEN = 16 bits
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_I2S_CTRL, mask);
    if (ret != HAL_OK) return ret;

    // Mise sous tension et réglage du DAC/ADC
    mask = 0x0000; // Unmute
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_ADCDAC_CTRL, mask);
    if (ret != HAL_OK) return ret;

    mask = 0x3C3C; // Niveau de volume du DAC
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_DAC_VOL, mask);
    if (ret != HAL_OK) return ret;

    mask = 0x0251; // BIAS_RESISTOR = 2, BIAS_VOLT = 5, GAIN = 1
    ret = sgtl5000_i2c_write_register(h_sgtl5000, SGTL5000_CHIP_MIC_CTRL, mask);
    if (ret != HAL_OK) return ret;

    return HAL_OK;
}

