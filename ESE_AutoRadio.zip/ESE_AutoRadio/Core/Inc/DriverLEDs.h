/*
 * DriverLEDs.h
 *
 *  Created on: Dec 4, 2024
 *      Author: nolan
 */

#ifndef DriverLEDs
#define DriverLEDs

#include "stm32l4xx_hal.h"
#include "shell.h"

typedef struct {
    SPI_HandleTypeDef *hspi;  // Handle SPI
    GPIO_TypeDef *cs_port;    // Port GPIO pour CS (Chip Select)
    uint16_t cs_pin;          // Pin GPIO pour CS
    uint8_t gpioa_state;      // État actuel des LEDs sur GPIOA
    uint8_t gpiob_state;      // État actuel des LEDs sur GPIOB
} LED_Driver_t;

void LED_Driver_Init(LED_Driver_t *driver, SPI_HandleTypeDef *hspi, GPIO_TypeDef *cs_port, uint16_t cs_pin);
void LED_Driver_SetGPIOA(LED_Driver_t *driver, uint8_t state);
void LED_Driver_SetGPIOB(LED_Driver_t *driver, uint8_t state);
void LED_Driver_SetLED(LED_Driver_t *driver, uint8_t port, uint8_t led, uint8_t state);
int shell_setled(h_shell_t *h_shell, int argc, char **argv);


#endif // DriverLEDs

