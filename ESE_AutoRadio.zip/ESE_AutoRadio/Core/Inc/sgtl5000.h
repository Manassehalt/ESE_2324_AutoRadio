/*
 * sgtl5000.h
 *
 *  Created on: Dec 10, 2024
 *      Author: nolan
 */
#ifndef SGTL5000_H
#define SGTL5000_H

#include "stm32l4xx_hal.h"
#include <stdint.h>

// Enumération des registres
typedef enum sgtl5000_registers_enum
{
    SGTL5000_CHIP_ID = 0x0000,
    SGTL5000_CHIP_DIG_POWER = 0x0002,
    SGTL5000_CHIP_CLK_CTRL = 0x0004,
    SGTL5000_CHIP_I2S_CTRL = 0x0006,
    SGTL5000_CHIP_SSS_CTRL = 0x000A,
    SGTL5000_CHIP_ADCDAC_CTRL = 0x000E,
    SGTL5000_CHIP_DAC_VOL = 0x0010,
    SGTL5000_CHIP_PAD_STRENGTH = 0x0014,
    SGTL5000_CHIP_ANA_ADC_CTRL = 0x0020,
    SGTL5000_CHIP_ANA_HP_CTRL = 0x0022,
    SGTL5000_CHIP_ANA_CTRL = 0x0024,
    SGTL5000_CHIP_LINREG_CTRL = 0x0026,
    SGTL5000_CHIP_REF_CTRL = 0x0028,
    SGTL5000_CHIP_MIC_CTRL = 0x002A,
    SGTL5000_CHIP_LINE_OUT_CTRL = 0x002C,
    SGTL5000_CHIP_LINE_OUT_VOL = 0x002E,
    SGTL5000_CHIP_ANA_POWER = 0x0030,
    SGTL5000_CHIP_PLL_CTRL = 0x0032,
    SGTL5000_CHIP_CLK_TOP_CTRL = 0x0034,
    SGTL5000_CHIP_ANA_TEST1 = 0x0038,
    SGTL5000_CHIP_SHORT_CTRL = 0x003C
} sgtl5000_registers_t;

// Structure de configuration
typedef struct
{
    I2C_HandleTypeDef *i2c_handle;
} h_sgtl5000_t;

// Déclarations des fonctions
HAL_StatusTypeDef sgtl5000_init(h_sgtl5000_t *h_sgtl5000);
HAL_StatusTypeDef sgtl5000_i2c_write_register(h_sgtl5000_t *h_sgtl5000, uint16_t reg, uint16_t value);
HAL_StatusTypeDef sgtl5000_i2c_read_register(h_sgtl5000_t *h_sgtl5000, uint16_t reg, uint16_t *value);
HAL_StatusTypeDef sgtl5000_i2c_set_bit(h_sgtl5000_t *h_sgtl5000, uint16_t reg, uint16_t mask);
HAL_StatusTypeDef sgtl5000_i2c_clear_bit(h_sgtl5000_t *h_sgtl5000, uint16_t reg, uint16_t mask);

#endif // SGTL5000_H

