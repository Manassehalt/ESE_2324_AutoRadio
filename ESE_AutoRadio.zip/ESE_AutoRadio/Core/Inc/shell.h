/*
 * shell.h
 *
 *  Created on: 7 juin 2019
 *      Author: Laurent Fiack
 */

#ifndef INC_LIB_SHELL_SHELL_H_
#define INC_LIB_SHELL_SHELL_H_

#include <stdint.h>

#define ARGC_MAX 8
#define BUFFER_SIZE 40
#define SHELL_FUNC_LIST_MAX_SIZE 64

struct h_shell_struct;

// Prototype pour les fonctions shell
typedef int (*shell_func_pointer_t)(struct h_shell_struct *h_shell, int argc, char **argv);

// Prototype pour les drivers shell
typedef uint8_t (*drv_shell_transmit_t)(const char *pData, uint16_t size);
typedef uint8_t (*drv_shell_receive_t)(char *pData, uint16_t size);

typedef struct shell_func_struct {
    char c;
    shell_func_pointer_t func;
    char *description;
} shell_func_t;

typedef struct drv_shell_struct {
    drv_shell_transmit_t transmit; // Fonction pour transmettre les données
    drv_shell_receive_t receive;   // Fonction pour recevoir les données
} drv_shell_t;

typedef struct h_shell_struct {
    int func_list_size;
    shell_func_t func_list[SHELL_FUNC_LIST_MAX_SIZE];
    char print_buffer[BUFFER_SIZE];
    char cmd_buffer[BUFFER_SIZE];
    drv_shell_t drv; // Drivers abstraits pour communication
} h_shell_t;

// Prototypes des fonctions
void shell_init(h_shell_t *h_shell);
int shell_add(h_shell_t *h_shell, char c, shell_func_pointer_t pfunc, char *description);
int shell_run(h_shell_t *h_shell);
void shell_process_char(h_shell_t *h_shell, char c);
int sh_help(h_shell_t *h_shell, int argc, char **argv);

#endif /* INC_LIB_SHELL_SHELL_H_ */


